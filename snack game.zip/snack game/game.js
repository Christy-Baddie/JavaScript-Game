// Get the canvas and its context
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

// Get the exit button
const exitButton = document.getElementById("exitButton");

// Set up the game variables
let score = 0;
let lives = 3;
let snacks = [];

// Function to create a random snack
function createSnack() {
  const snackTypes = ["🍪", "🍩", "🍕", "🍎", "🍿", "❤️"];
  const randomSnack = snackTypes[Math.floor(Math.random() * snackTypes.length)];
  const randomX = Math.random() * (canvas.width - 40) + 20;
  const newSnack = {
    x: randomX,
    y: 0,
    type: randomSnack,
  };
  snacks.push(newSnack);
}

// Function to draw the player's score and lives on the canvas
function drawHUD() {
  ctx.font = "24px Arial";
  ctx.fillStyle = "white"; // Set the text color to white
  ctx.fillText(`Score: ${score}`, 10, 30);
  ctx.fillText(`Lives: ${lives}`, canvas.width - 100, 30);
}

// Function to update the game state
function update() {
  // Clear the canvas
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Check if the player has caught a snack
  for (let i = snacks.length - 1; i >= 0; i--) {
    snacks[i].y += 3; // Adjust snack falling speed
    if (snacks[i].y >= canvas.height) {
      // Snack missed, remove it from the array
      snacks.splice(i, 1);
      lives--;
      if (lives <= 0) {
        // Game over condition
        alert("Game Over! Your final score is: " + score);
        document.location.reload();
      }
    } else {
      // Draw the snack on the canvas
      ctx.font = "30px Arial";
      ctx.fillText(snacks[i].type, snacks[i].x, snacks[i].y);
    }
  }

  // Draw the player's score and lives
  drawHUD();

  // Request animation frame to update the game loop
  requestAnimationFrame(update);
}

// Function to handle the player's mouse movement
function onMouseMove(event) {
  const rect = canvas.getBoundingClientRect();
  const mouseX = event.clientX - rect.left;
  const mouseY = event.clientY - rect.top;

  // Check if the mouse is over any of the falling snacks
  for (let i = snacks.length - 1; i >= 0; i--) {
    if (
      mouseX >= snacks[i].x &&
      mouseX <= snacks[i].x + 40 &&
      mouseY >= snacks[i].y &&
      mouseY <= snacks[i].y + 40
    ){
      // Check the type of the snack caught
      if (snacks[i].type === "❤️") {
        // Heart caught, increase the lives
        snacks.splice(i, 1);
        lives++;
      } else {
        // Regular snack caught, remove it from the array and increase the score
        snacks.splice(i, 1);
        score++;
      }
      break; 
    }
  }
}

// Function to exit the game and ask for a new round
function exitGame() {
  const playAgain = confirm("Game Over! Your final score is: " + score + "\nDo you want to play another round?");
  if (playAgain) {
    // Reset game state and start a new round
    score = 0;
    lives = 3;
    snacks = [];
    update();
  } else {
    // End the game session
    alert("Thank you for playing!");
    document.location.reload();
  }
}

//  event listener for mouse movement
canvas.addEventListener("mousemove", onMouseMove);

//  event listener for exit button click
exitButton.addEventListener("click", exitGame);

// loop to start game
update();

// Generate new snacks every 1.5 second
setInterval(createSnack, 1500);
